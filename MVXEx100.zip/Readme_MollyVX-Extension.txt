How to create MollyVX-Extension
----------------------------------------

Requirements:
 -Original MollyVX (MollyVX-10-25-2022.zip)
 -OptiFine 1.17.1 or newer
   *Note:This shader is NOT support Iris!

Requires the shader pack MollyVX-10-25-2022.zip. You can create MollyVX-Extension.zip by to patch that shader pack.

MollyVX is Minecraft shader developed by Rutherin and is available through paid tier membership on Patreon.
https://www.patreon.com/rutherin

The patch is provided as diff text file (unified format).
Apply it to original shader pack using patch tool.

As a patch tool for Windows, included GNU patch, which is released under the GPL at 
https://gnuwin32.sourceforge.net/packages/patch.htm
The GnuWin_patch folder contains the Binaries, Documentation, and Sources required for redistribution.

Tool for Windows to automate patching will also be included.

[How to use]
========================================
1. Extract MVXEx100.zip.

2. Double-click the shortcut 'mollyvx_patch' in the extracted folder to launch it.
The process is created using a PowerShell script. PowerShell scripts(.ps1) cannot be executed by double-clicking, and must be launched from the shortcut 'mollyvx_patch' that has been granted permission to run the script. Note that the included patch.exe is a patch tool that is called as a command within this tool, and double-clicking it will not process anything.

3. Click the [Browse...] button to specify the original shader pack ZIP file. This file is only referenced and will not be directly overwritten.

4. Press the [Start] button to begin processing. When complete, MollyVX-Extension.zip will be output to the same folder as this tool.
========================================

The completed MollyVX-Extension.zip will only work with OptiFine, just like the original MollyVX.

I don't know if there are cases where patches are applied on OS other than Windows, but if you can manually execute the patch command on a non-Windows OS, it seems possible to apply it. However, there is one line in the difference that contains the § symbol (double section), but § could not be processed by any diff/patch tool for Windows (it becomes garbled). Therefore, as a workaround, § is replaced with @ and processed. In other words, before patching, you need to manually change § to @ in the corresponding part of the original source to be patched. You can see the location of the corresponding part by looking at the PowerShell script. The difference text file is written using @ instead of §, so patch will work properly now.


----------------------------------------
[about LICENSE]

This patch does not function by itself, but requires the original MollyVX shader pack and provides a means to extend its functionality.
Shader packs with this patch will maintain the license terms of the original MollyVX shader pack.
In other words, users can use the patched shaders for personal use as private modifications, but they cannot redistribute them without the permission of the original MollyVX shader pack author.

This mod includes a GNU patch under the GPL, but the PowerShell script provided as a patch tool only automates the execution of patch commands, and is not subject to any software licenses, including the GPL.

## 2024-11-03 by GlowK ##
