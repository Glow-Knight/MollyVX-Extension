﻿#-------------------------------------------------------------------------------
#  mollyvx_patch.ps1
#  MollyVX-10-25-2022.zip にパッチを当てる
#    patch.exeは Patch for Windows ( https://gnuwin32.sourceforge.net/packages/patch.htm )
#    で公開されている patch-2.5.9-7-bin.zip を使用
#-------------------------------------------------------------------------------

# ファイル/フォルダ選択ダイアログ、メッセージボックス等を使用するためのアセンブリのロード
Add-Type -AssemblyName System.Windows.Forms

# GDI+ の基本的なグラフィックス機能
Add-Type -AssemblyName System.Drawing

# WPF(Windows Presentation Foundation)の機能を使用するためのアセンブリのロード
Add-Type -AssemblyName PresentationFramework


$ErrorActionPreference = 'Stop' # このスクリプト内でのエラー発生時に処理を中断する（PowerShellの既定は Continue:エラーメッセージを出して処理継続）

# $PWDは通常、実行の操作をしたディレクトリを示すが、実行ショートカットの「作業フォルダー」を指定するとそのフォルダーを示す。
# $MyInvocation.MyCommand.Path はスクリプト自身のパスを取得する
$SaveDir=$PWD.Path
#$myPath = $MyInvocation.MyCommand.Path
#$SaveDir = Split-Path -Parent $myPath

$myLog = $SaveDir + "\patchLog.txt"
$isLog=$false

function writeLog($str) {
    $date = Get-Date -Format G
    $logStr = $date + " : " + $str
    Write-Output $logStr | Out-File -Append $myLog
}

$script:inputFile = ""  # 子スコープから読み書きするのでscriptスコープで定義
$expandDir = $SaveDir + "\MollyVX-10-25-2022"
$compressPath = $expandDir + "\*"
$outputFile = $SaveDir + "\MollyVX-Extension.zip"

$msgBox = [System.Windows.MessageBox]
$buttonsOK=[System.Windows.MessageBoxButton]::OK
$defaultButton=[System.Windows.MessageBoxResult]::OK  # 既定の結果
$dummyWindow = New-Object System.Windows.Window
$dummyWindow.Width = 100
$dummyWindow.Height = 100
$dummyWindow.WindowStartupLocation = [System.Windows.WindowStartupLocation]::CenterScreen
$dummyWindow.Topmost = $true


#---- 高DPI(スケーリング)に対応したフォームの作成 ----
# [High DPI] 最初にSetProcessDPIAwareを実行して高DPIの対応を宣言する
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;

public class ProcessDPI {
    [DllImport("user32.dll", SetLastError=true)]
    public static extern bool SetProcessDPIAware();      
}
'@ -ReferencedAssemblies 'System.Drawing.dll'
$null = [ProcessDPI]::SetProcessDPIAware()

# ビジュアルスタイルを有効にする
[System.Windows.Forms.Application]::EnableVisualStyles()

# フォーム作成
$form = New-Object System.Windows.Forms.Form

# [High DPI] AutoScaleModeのDpi指定を機能させるには（DPIに従ったスケーリングでコントロールが配置およびサイズ設定されるには）、
# フォームの作成直後にSuspendLayoutを呼び出し、すべてのコントロールを作成して配置したらResumeLayoutを呼び出す。
$form.SuspendLayout()
$form.AutoScaleDimensions =  New-Object System.Drawing.SizeF(96, 96)  # コントロールがデザインされたときのサイズを設定する
$form.AutoScaleMode  = [System.Windows.Forms.AutoScaleMode]::Dpi # 自動スケーリングのモード = Dpi:ディスプレイの解像度に応じてスケールを制御

$form.Text = 'Patch tool'
#$form.Size = New-Object System.Drawing.Size(300,200)  # フォーム全体のサイズで指定
$form.ClientSize = New-Object System.Drawing.Size(400,200)  # クライアント領域のサイズで指定（枠やタイトルバーを除いたサイズ）
$form.StartPosition = 'CenterScreen'

$label1 = New-Object System.Windows.Forms.Label
$label1.Location = New-Object System.Drawing.Point(10,10)
$label1.Size = New-Object System.Drawing.Size(350,20)
$label1.Text = 'Select ZIP file of MollyVX-10-25-2022 shader pack'
$form.Controls.Add($label1)

# DPI Scalingの取得
$DPISetting = (Get-ItemProperty 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name AppliedDPI).AppliedDPI
[float]$displayScale = $DPISetting / 96;  # 1.0,1.25,1.5…等の値にする

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10,30)
$textBox.Size = New-Object System.Drawing.Size(305,60)
$textBox.Multiline = $true
# PowerShell ISEからの実行では、テキストボックスだけ、なぜかAutoScaleが効かないので、スケーリング係数をかけたフォントサイズを直指定する
# 通常実行では大丈夫か？
#$Font = New-Object System.Drawing.Font($textBox.Font.Name,(12 * $displayScale))
$Font = New-Object System.Drawing.Font($textBox.Font.Name,12)
$textBox.Font =  $Font
$form.Controls.Add($textBox)

<#
$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(230,90)
$cancelButton.Size = New-Object System.Drawing.Size(60,23)
$cancelButton.Text = 'Close'
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)
#>

$browseButton = New-Object System.Windows.Forms.Button
$browseButton.Location = New-Object System.Drawing.Point(320,30)
$browseButton.Size = New-Object System.Drawing.Size(70,23)
$browseButton.Text = 'Browse...'
$form.Controls.Add($browseButton)

# browseボタンのクリックイベント
$Browse = {
    $fileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $fileDialog.Filter = "ZIP archive files|*.zip|All Files|*.*"
    $fileDialog.Title = "Select"
    if ($fileDialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        # オブジェクトの後始末
        $fileDialog.Dispose()
        return
    }
    $script:inputFile = $fileDialog.FileName
    $textBox.Text = $script:inputFile
}
$browseButton.Add_Click($Browse)

$label2 = New-Object System.Windows.Forms.Label
$label2.Location = New-Object System.Drawing.Point(120,145)
$label2.Size = New-Object System.Drawing.Size(70,20)
$label2.Text = 'Patch start'
$form.Controls.Add($label2)

$submitButton = New-Object System.Windows.Forms.Button
$submitButton.Location = New-Object System.Drawing.Point(200,140)
$submitButton.Size = New-Object System.Drawing.Size(90,23)
$submitButton.Text = 'Start'
#$submitButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
#$form.AcceptButton = $okButton
$form.Controls.Add($submitButton)

# submitボタンのクリックイベント
$Submit = {

    $form.Controls.Remove($submitButton)
    $label2.Text = 'Wait ...'
    $form.Refresh()  # 再描画しないとラベルのテキスト変更が反映されなかった

    # 解凍先フォルダ、出力ファイルの存在チェック
    if( Test-Path $expandDir ) {
        $icon=[System.Windows.MessageBoxImage]::Error
        $msgBoxResult = $msgBox::Show($dummyWindow,'Folder MollyVX-10-25-2022 already exists here', 'mollyvx_patch', $buttonsOK, $icon, $defaultButton)
        return
    }
    if( Test-Path $outputFile ) {
        $icon=[System.Windows.MessageBoxImage]::Error
        $msgBoxResult = $msgBox::Show($dummyWindow,'Output file MollyVX-Extension.zip already exists here', 'mollyvx_patch', $buttonsOK, $icon, $defaultButton)
        return
    }

    # MollyVX-10-25-2022.zipを解凍する
    Expand-Archive -Path $script:inputFile -DestinationPath $expandDir

    # "§"対策
    # § の記号（ダブルセクション）はdiff/patchツールいずれでも処理できず文字化けになり、そのままではエラーになる。そこで、差分テキスト、適用対象ソースファイルの
    # 両方で、§を含む箇所はあらかじめ @ に置き換えておくことにする。
    $targetFile = $expandDir + "\shaders\lang\en_US.lang"
    #$beforeStr = "Raytraced Refraction §cWIP§r"
    # PowerShellにおいても、文字列中に§があるとなぜか検索できない。
    # 回避策として正規表現でその字は飛ばしたいが、§は正規表現の「.」(任意の1文字)でもなぜか一致しない。「.+」(1文字以上の任意の文字列)でなら拾える。
    $beforeStr = "Raytraced Refraction .+cWIP.+r"
    $afterStr = "Raytraced Refraction @cWIP@r"

    try
    {
        (Get-Content $targetFile -ErrorAction Stop) -creplace $beforeStr,$afterStr | Out-File -Encoding default $targetFile
    }
    catch
    {
        $icon=[System.Windows.MessageBoxImage]::Error
        #$msgBoxResult = $msgBox::Show($dummyWindow,'置換でエラーが発生しました : ' + $PSItem, 'mollyvx_patch', $buttonsOK, $icon, $defaultButton)
        $msgBoxResult = $msgBox::Show($dummyWindow,'text replacing error : ' + $PSItem, 'mollyvx_patch', $buttonsOK, $icon, $defaultButton)
        # $PSItem:パイプラインオブジェクト内の現在のオブジェクトを格納する自動変数
    }

    # パッチを適用する
    cat diff_MVXEx100.txt | ./patch -u -p0

    # パッチ適用済みのリソースをZIP圧縮する
    Compress-Archive -Path $compressPath -DestinationPath $outputFile

    Remove-Item $expandDir -Recurse -Force

    $icon=[System.Windows.MessageBoxImage]::Information
    #$dummyWindow.Show()
    #$msgBoxResult = $msgBox::Show($dummyWindow,'パッチ適用済みのシェーダーパックを作成しました。', 'mollyvx_patch', $buttonsOK, $icon, $defaultButton)
    $msgBoxResult = $msgBox::Show($dummyWindow,'Completed creating a new patched shader pack', 'mollyvx_patch', $buttonsOK, $icon, $defaultButton)
    #$dummyWindow.Close()

    $label2.Text = 'Patch start'
    $form.Controls.Add($submitButton)

}
$submitButton.Add_Click($Submit)

# フォームをアクティブにしてtextBoxにフォーカスを設定する
$form.Add_Shown({$textBox.Select()})

# [High DPI] 最後にResumeLayoutを実行してからShowDialogする
$form.ResumeLayout()

$result = $form.ShowDialog()

<#
if ($result -eq [System.Windows.Forms.DialogResult]::Cancel)
{
    # nop
}
#>
# ログ記録
<#
if ($isLog) {
    $userName = (whoami).Split('\')[1]
    writeLog("[image]$DateTime.$Format [user]$userName")
}
#>

exit
